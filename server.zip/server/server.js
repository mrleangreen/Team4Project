const express = require('express');
const app = express();
const cors = require('cors');

// CORS Verification and Body Parsing middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Localhost/API stuff
const PORT = 5000;
const HOST = "localhost";
const API_URL = "https://api.warframe.market/v1";

// Double check authorization
app.use('', (req, res, next) => {
   if (req.headers.authorization) {
       next();
   } else {
       res.sendStatus(403); // Forbidden
   }
});

// ===================================================
// || [Ian_C]: IT WORKS... IT'S ALIVE... HAHAHAHAHA ||
// ===================================================

// ===== GET KEY WITH THIS =====
// await response.headers.get("set-cookie")

app.post("/https://api.warframe.market/v1/auth/signin", async (req, res) => {
	const response = await fetch("https://api.warframe.market/v1/auth/signin", {
		method: "POST",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		},
		body: JSON.stringify(req.body)
	})
	
	res.send(await response.json());
})

app.post(/api.warframe.market/, async (req, res) => {
	const response = await fetch(req.originalUrl.substring(1), {
		method: "POST",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		},
		body: JSON.stringify(req.body)
	})
	
	res.send(await response.json());
})

// Any get request with "api.warframe.market" gets used here
app.get(/api.warframe.market/, async function (req, res) {
	//console.log(req);
	const response = await fetch(req.originalUrl.substring(1), {
		method: "GET",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		}
	});
	
	res.send(await response.json());
})

// This lets it run in the background, listening until the program is killed (Will add startup and shutdown for this later)
app.listen(PORT, HOST, () => {
   console.log(`Running proxy at ${HOST}:${PORT}`);
});