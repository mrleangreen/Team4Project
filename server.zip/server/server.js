const express = require('express');
const cors = require('cors');
const PORT = 5000;

const app = express();

app.use(cors());									// CORS authentication
/*
app.use(express.json());							// POST Requirments
app.use(express.urlencoded({ extended: true }));
*/

/*
var header = JSON.stringify({
	"Content-Type": "application/json; utf-8",
    "Accept": "application/json",
    "Authorization": "JWT",
    "platform": "pc",
    "language": "en",
});

var body = JSON.stringify({
	"auth_type": "header",
	"email": "",
	"password": "",
	"device_id": "PC"
});
*/

/*
app.post("/https://api.warframe.market/v1/auth/signin", async (req, res) => {
	const response = await fetch("https://api.warframe.market/v1/auth/signin", {
		method: "POST",	
		header: res.header,
		body: res.body
	});
	res.json(await response.json());
	console.log({requestBody: req.body});
});
*/

// Any get request with "api.warframe.market" gets used here
app.get(/api.warframe.market/, async function (req, res) {
	const response = await fetch(req.originalUrl.substring(1));
	res.json(await response.json());
});

// A quick check to verify middleware is running
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));