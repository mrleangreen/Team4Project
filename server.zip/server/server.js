const app = require('express')();
const cors = require('cors');
const {createProxyMiddleware} = require('http-proxy-middleware');

// CORS still doesn't like this but 
app.use(cors());

// Localhost/API stuff
const PORT = 5000;
const HOST = "localhost";
const API_URL = "https://api.warframe.market/v1";

// Double check authorization
app.use('', (req, res, next) => {
   if (req.headers.authorization) {
       next();
   } else {
       res.sendStatus(403); // Forbidden
   }
});

/*
Much smaller package for our GET and POST requests here...
Might expand on this later, but for now this can handle everything
																		   vvvvv Then add the specific function to call
NOTE: When calling the API, write it out as "http://localhost:5000/WFM_API/items"
																   ^^^^^^^ Use this instead of "https://api.warframe.market/v1"
*/
app.use('/WFM_API', createProxyMiddleware({
   target: API_URL,
   changeOrigin: true,
   pathRewrite: {
       [`^/WFM_API`]: '',
   },
}));

// Little test function for testing purposes
app.get('/test', (req, res, next) => {
   res.send(JSON.stringify("Hello world! This shows the server is running and requests are working"));
});

// This lets it run in the background, listening until the program is killed (Will add startup and shutdown for this later)
app.listen(PORT, HOST, () => {
   console.log(`Running Proxy at ${HOST}:${PORT}`);
});

/*
===================================================
|| [Ian_C]: Keeping this here... just in case... ||
===================================================

var header = ({
	"Content-Type": "application/json;",
	"Accept": "application/json",
	"Authorization": "JWT"
})

var body = ({
	"auth_type": "header",
	"email": "",
	"password": "",
	"device_id": "pc"
})

app.post("/https://api.warframe.market/v1/auth/signin", upload.array(), async (req, res) => {
	const response = await fetch("https://api.warframe.market/v1/auth/signin", {
		"credentials": "include",
		"method": "POST",	
		"header": header,
		"body": body
	})
	.then(res => res.json())
	.then(data => console.log(data))
	
	//res.send(await res.json())
	console.log("POST request made!")
	console.log(req.body)
})

// Any get request with "api.warframe.market" gets used here
app.get(/api.warframe.market/, async function (req, res) {
	const response = await fetch(req.originalUrl.substring(1))
	res.json(await response.json())
})
*/