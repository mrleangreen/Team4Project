const app = require('express')();
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const bodyParser = require('body-parser');
const rateLimit = require('express-rate-limit');

app.use(cors());
app.use(bodyParser.json());

const PORT = 5000;
const HOST = "localhost";
const API_URL = "https://api.warframe.market/v1";

// Rate limiting: 1 request per second
const limiter = rateLimit({
    windowMs: 1000, // 1 second
    max: 1, // limit each IP to 1 requests per windowMs
    message: "Too many requests from this IP, please try again after a second"
});

app.use(limiter); // Apply to all requests

app.use('', (req, res, next) => {
    if (req.headers.authorization) {
        next();
    } else {
        res.sendStatus(403); // Forbidden
    }
});

app.use('/WFM_API', createProxyMiddleware({
    target: API_URL,
    changeOrigin: true,
    pathRewrite: {
        [`^/WFM_API`]: '',
    },
}));

app.get('/test', (req, res) => {
    res.json("Hello world! This shows the server is running and requests are working");
});

app.listen(PORT, HOST, () => {
    console.log(`Running Proxy at ${HOST}:${PORT}`);
});

// Handling the POST request for user sign-in at the API endpoint
app.post('/auth/signin', async (req, res) => {
    const fetch = require('node-fetch');
    const response = await fetch(`${API_URL}/auth/signin`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer ' + req.headers.authorization // Assuming the JWT token is passed in headers
        },
        body: JSON.stringify(req.body)
    });
    const data = await response.json();
    console.log(data);
    res.status(response.status).send(data);
});

// Proxy GET requests for the Warframe API
app.get(/^\/api\/.*$/, createProxyMiddleware({
    target: API_URL,
    changeOrigin: true,
    pathRewrite: (path, req) => path.replace(/^\/api\//, '/')
}));
