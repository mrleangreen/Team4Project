var headerStuff = new Headers({
	"Content-Type": "application/json",
    "Accept": "application/json",
    "Authorization": "JWT"
})

var itemID = "";
var name = "";

async function signIn(){
	var loginStuff = JSON.stringify({
		"auth_type": "header",
		"email": document.getElementById("email").value,
		"password": document.getElementById("password").value,
		"device_id": "pc"
	})
	
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/auth/signin", {
		method: "POST",
		headers: headerStuff,
		body: loginStuff
	})
	var rBody = await response.json();
	
	headerStuff = new Headers({
		"Content-Type": "application/json",
		"Accept": "application/json",
		"Authorization": rBody["key"]
	})
	
	name = rBody["name"];
	console.log("Login successful!");
}

async function setBuy() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/items/" + document.getElementById("URLNameIn").value, {
		method: "GET",
		headers: headerStuff
	})
	var rBody = await response.json();
	itemID = rBody["payload"]["item"]["id"]
	
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/items/" + document.getElementById("URLNameIn").value + "/orders", {
		method: "GET",
		headers: headerStuff
	})
	rBody = await response.json();
	
	var lowest = rBody["payload"]["orders"][0];
	for (var a = 0; a < rBody["payload"]["orders"].length; a++) {
		if (lowest["order_type"] != "buy" || lowest["user"]["status"] != "ingame"){
			lowest = rBody["payload"]["orders"][a];
		}
		
		if (rBody["payload"]["orders"][a]["order_type"] == "buy" && rBody["payload"]["orders"][a]["user"]["status"] == "ingame"	&& lowest["platinum"] < rBody["payload"]["orders"][a]["platinum"]) {
			lowest = rBody["payload"]["orders"][a];
		}
	}
	
	var buyStuff = JSON.stringify({
		"item": itemID,
		"order_type": "buy",
		"platinum": lowest["platinum"],
		"quantity": 1
	})
	
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/profile/orders", {
		method: "POST",
		headers: headerStuff,
		body: buyStuff
	})
	rBody = await response.json();
	
	console.log(rBody);
	idItem = rBody["payload"]["order"]["id"];
	console.log(idItem);
}

async function getAllItems() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/items", {
		method: "GET",
		headers: headerStuff
	})
	var rBody = await response.json();
	
	console.log(rBody);
}

async function getAllOrders() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/items/" + document.getElementById("URLNameIn0").value + "/orders", {
		method: "GET",
		headers: headerStuff
	})
	var rBody = await response.json();
	
	console.log(rBody);
}