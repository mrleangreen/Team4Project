let formSubmitted = false;

function openForm() {
    document.getElementById("form-popup").style.display = "block";
    if (!formSubmitted) {
        addFormSubmitListener();
    }
}

function closeForm() {
    document.getElementById("form-popup").style.display = "none";
}

function addFormSubmitListener() {
    document.getElementById("add-form").addEventListener("submit", function(event) {
        event.preventDefault();

        const type = document.getElementById("type").value;
        const name = document.getElementById("name").value;
        const amount = parseFloat(document.getElementById("amount").value).toFixed(2);

        const listItem = document.createElement("li");
        listItem.textContent = `${name}: $${amount}`;
        listItem.dataset.amount = amount;

        if (type === "expense") {
            document.getElementById("expenses-list").querySelector("ul").appendChild(listItem);
            saveData('expenses', { name, amount });
        } else if (type === "asset") {
            document.getElementById("assets-list").querySelector("ul").appendChild(listItem);
            saveData('assets', { name, amount });
        } else {
            document.getElementById("revenue-list").querySelector("ul").appendChild(listItem);
            saveData('revenue', { name, amount });
        }

        updateTotals();
        closeForm();
    });

    formSubmitted = true;
}

function updateTotals() {
    const expenseItems = Array.from(document.getElementById("expenses-list").querySelectorAll("li"));
    const expenseTotal = expenseItems.reduce((total, item) => total + parseFloat(item.dataset.amount), 0);
    document.querySelector(".total-expense").textContent = expenseTotal.toFixed(2);

    const assetItems = Array.from(document.getElementById("assets-list").querySelectorAll("li"));
    const assetTotal = assetItems.reduce((total, item) => total + parseFloat(item.dataset.amount), 0);
    document.querySelector(".total-asset").textContent = assetTotal.toFixed(2);

    const revenueItems = Array.from(document.getElementById("revenue-list").querySelectorAll("li"));
    const revenueTotal = revenueItems.reduce((total, item) => total + parseFloat(item.dataset.amount), 0);
    document.querySelector(".total-revenue").textContent = revenueTotal.toFixed(2);

    const combinedTotal = assetTotal + revenueTotal - expenseTotal;
    const combinedTotalSpan = document.querySelector(".overall-total");
    combinedTotalSpan.textContent = combinedTotal.toFixed(2);

    // Apply color based on the combined total
    combinedTotalSpan.style.color = combinedTotal >= 0 ? 'green' : 'red';
}

function saveData(key, data) {
    let existingData = JSON.parse(localStorage.getItem(key)) || [];
    existingData.push(data);
    localStorage.setItem(key, JSON.stringify(existingData));
}


