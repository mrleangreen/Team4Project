const express = require('express');
const app = express();
const cors = require('cors');

// CORS Verification and Body Parsing middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Localhost/API stuff
const PORT = 5000;
const HOST = "localhost";
const API_URL = "https://api.warframe.market/v1";

// Double check authorization
app.use('', (req, res, next) => {
	if (req.headers["authorization"]) {
		next();
	} else {
		res.sendStatus(403); // Forbidden
	}
});

// ===================================================
// || [Ian_C]: IT WORKS... IT'S ALIVE... HAHAHAHAHA ||
// ===================================================

// ===== GET KEY WITH THIS =====
// await response.headers.get("set-cookie")

app.post("/https://api.warframe.market/v1/auth/signin", async (req, res) => {
	const response = await fetch("https://api.warframe.market/v1/auth/signin", {
		method: "POST",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		},
		body: JSON.stringify(req.body)
	})
	var hold = await response.json();

	if (response.status == 200) {
		var sendBack = JSON.stringify({
			"name": hold["payload"]["user"]["ingame_name"],
			"key": response.headers.get("authorization")
		})

		res.send(sendBack);
	} else {
		console.log("Sign in unsuccessful");
		res.sendStatus(404);
	}
})

app.post(/api.warframe.market/, async (req, res) => {
	const response = await fetch(req.originalUrl.substring(1), {
		method: "POST",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		},
		body: JSON.stringify(req.body)
	})

	res.send(await response.json());
})

// Any get request with "api.warframe.market" gets used here
app.get(/api.warframe.market/, async (req, res) => {
	const response = await fetch(req.originalUrl.substring(1), {
		method: "GET",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		}
	})

	res.send(await response.json());
})

app.put(/api.warframe.market/, async (req, res) => {
	const response = await fetch(req.originalUrl.substring(1), {
		method: "PUT",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		},
		body: JSON.stringify(req.body)
	})

	res.send(await response.json());
})

app.delete(/api.warframe.market/, async (req, res) => {
	const response = await fetch(req.originalUrl.substring(1), {
		method: "DELETE",
		headers: {
			"Content-Type": req.headers["content-type"],
			"Accept": req.headers["accept"],
			"Authorization": req.headers["authorization"]
		}
	})

	res.send(await response.json());
})
var headerStuff = new Headers({
	"Content-Type": "application/json",
	"Accept": "application/json",
	// The actual authorization token should be set after successful login
	// "Authorization": "Bearer YOUR_TOKEN_HERE"
});

var name = "";
var idItem = "";

var loginStuff = JSON.stringify({
	"auth_type": "header",
	"email": "<insert email here>",  // Replace with actual email before use
	"password": "<insert password here>",  // Replace with actual password before use
	"device_id": "pc"
});

var buyStuff = JSON.stringify({
	"item": "54aae292e7798909064f1575",
	"order_type": "buy",
	"platinum": 1,
	"quantity": 1
});

var buyStuffUpdate = JSON.stringify({
	"item": "54aae292e7798909064f1575",
	"order_type": "buy",
	"platinum": 10,
	"quantity": 1
});

// Function to handle user sign-in
async function signIn() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/auth/signin", {
		method: "POST",
		headers: headerStuff,
		body: loginStuff
	});
	var rBody = await response.json();

	// Update the headers with the authorization token received after login
	headerStuff.set("Authorization", rBody["key"]);

	name = rBody["name"];
	console.log(name);
	console.log(rBody["key"]);
}

// Function to submit a buy order
async function setBuy() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/profile/orders", {
		method: "POST",
		headers: headerStuff,
		body: buyStuff
	});
	var rBody = await response.json();

	console.log(rBody);
	idItem = rBody["payload"]["order"]["id"];
	console.log(idItem);
}

// Function to retrieve all items
async function getAllItems() {
	var response = await fetch("http://localhost:5000/https://api.warframe.market/v1/most_recent", {
		method: "GET",
		headers: headerStuff
	});
	var rBody = await response.json();

	console.log(rBody);
}

// Function to retrieve all orders for a user
async function getAllOrders() {
	var response = await fetch(`http://localhost:5000/https://api.warframe.market/v1/profile/${name}/orders`, {
		method: "GET",
		headers: headerStuff
	});
	var rBody = await response.json();

	console.log(rBody);
}


// This lets it run in the background, listening until the program is killed (Will add startup and shutdown for this later)
app.listen(PORT, HOST, () => {
	console.log(`Running proxy at ${HOST}:${PORT}`);
});