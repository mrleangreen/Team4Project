window.onload = function() {
    loadData('expenses', 'expense-report');
    loadData('assets', 'asset-report');
    loadData('revenue', 'revenue-report');
    updateFinancialSummary();
};

function loadData(key, elementId) {
    let data = JSON.parse(localStorage.getItem(key)) || [];
    let reportElement = document.getElementById(elementId);
    data.forEach(item => {
        let listItem = document.createElement('li');
        listItem.textContent = `${item.name}: $${item.amount}`;
        reportElement.appendChild(listItem);
    });
}

function updateFinancialSummary() {
    let expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    let assets = JSON.parse(localStorage.getItem('assets')) || [];
    let revenue = JSON.parse(localStorage.getItem('revenue')) || [];

    let totalExpenses = expenses.reduce((total, item) => total + parseFloat(item.amount), 0);
    let totalAssets = assets.reduce((total, item) => total + parseFloat(item.amount), 0);
    let totalRevenue = revenue.reduce((total, item) => total + parseFloat(item.amount), 0);

    document.getElementById('total-assets').textContent = totalAssets.toFixed(2);
    document.getElementById('total-liabilities').textContent = totalExpenses.toFixed(2); // Assuming all expenses are liabilities
    document.getElementById('net-worth').textContent = (totalAssets - totalExpenses).toFixed(2);
    document.getElementById('cash-flow').textContent = (totalRevenue - totalExpenses).toFixed(2);
}
